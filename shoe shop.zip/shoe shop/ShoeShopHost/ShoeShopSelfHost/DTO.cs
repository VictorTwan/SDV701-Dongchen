﻿using System;

namespace ShoeShopSelfHost
{ // Data object for model in service 
    public class clsShoe
    {

        public string model_id { get; set; }
        public string brand_name { get; set; }
        public int size { get; set; }
        public int quantity { get; set; }
        public string colour { get; set; }
        public decimal price { get; set; }
        public string used_condition { get; set; }
        public char catergory { get; set; }
    }

    public class clsOrder
    {

        public int order_num { get; set; }
        public int model_id { get; set; }
        public string customer_name { get; set; }
        public int customer_phone { get; set; }
        public string customer_address { get; set; }
        public DateTime order_date { get; set; }

    }

    public class clsBrand
    {

        public string brand_name { get; set; }
        public string brand_descrip { get; set; }

        public override string ToString()
        {
            return brand_name;
        }

    }

}
