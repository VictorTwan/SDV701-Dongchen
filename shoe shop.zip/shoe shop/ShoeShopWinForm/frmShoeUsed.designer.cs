namespace ShoeShopApp
{
    partial class frmShoeUsed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCondition = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCondition
            // 
            this.txtCondition.Location = new System.Drawing.Point(97, 141);
            this.txtCondition.Name = "txtCondition";
            this.txtCondition.Size = new System.Drawing.Size(232, 21);
            this.txtCondition.TabIndex = 5;
            // 
            // Label5
            // 
            this.Label5.Location = new System.Drawing.Point(9, 144);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(80, 21);
            this.Label5.TabIndex = 54;
            this.Label5.Text = "Condition";
            // 
            // frmPhotograph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(350, 178);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txtCondition);
            this.Name = "frmPhotograph";
            this.Text = "Shoe Details - Used";
            this.Controls.SetChildIndex(this.txtCondition, 0);
            this.Controls.SetChildIndex(this.Label5, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        internal System.Windows.Forms.TextBox txtCondition;
        internal System.Windows.Forms.Label Label5;
    }
}
