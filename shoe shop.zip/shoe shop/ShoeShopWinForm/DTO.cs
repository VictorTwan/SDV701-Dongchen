﻿using System;

namespace ShoeShopApp
{ // Data Objects for model
    public class clsShoe
    {
        public string   model_id { get; set; }
        public string   brand_name { get; set; }
        public int      size { get; set; }
        public int      quantity { get; set; }
        public string   colour { get; set; }
        public decimal  price { get; set; }
        public string   used_condition { get; set; }
        public char     catergory { get; set; }

        public static clsShoe NewWork(char prChoice)
        {
            return new clsShoe() { catergory = Char.ToUpper(prChoice) } ;
        }

        public static readonly string FACTORY_PROMPT = "Enter N for New Shoes, or U for Used Shoes?";

        public override string ToString()
        {
            return catergory.ToString() + "\t" + model_id.ToString() + "\t" + size.ToString() + "\t" + colour.ToString() + "\t" + price.ToString(); ; ;
        }
    }

    public class clsOrder
    {
        public int       order_num { get; set; }
        public int       model_id { get; set; }
        public string    customer_name { get; set; }
        public int       customer_phone { get; set; }
        public string    customer_address { get; set; }
        public DateTime  order_date { get; set; }

        public string QuickView()
        {
            return "Order Details: \n Order #: " + order_num.ToString() + " \n Model ID: " + model_id.ToString() + 
                " \n Name: " + customer_name.ToString() + " \n Address: " + customer_phone.ToString() + 
                " \n Phone: " + customer_address.ToString() + " \n Order Date: " + order_date.Date.ToShortDateString();
        }

        public override string ToString()
        {
            return customer_name + "\t" + order_num.ToString();
        }
    }

    public class clsBrand
    {
        public string brand_name { get; set; }
        public string brand_descrip { get; set; }

        public static string storename = "Nelson Shoes";

        public override string ToString()
        {
            return brand_name;
        }
    }

}
