﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;

namespace ShoeShopSelfHost
{ // Controller to get request for select, update, insert or delete from database
   public class ShoeController : ApiController
    {
        public List<clsBrand> GetBrands()
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM brand", null);
            List<clsBrand> lcNames = new List<clsBrand>();
            clsBrand lcBrand;
            foreach (DataRow dr in lcResult.Rows)
            {
                lcBrand = new clsBrand();
                lcBrand.brand_name = dr["brand_name"].ToString();
                lcBrand.brand_descrip = dr["brand_descrip"].ToString();
                lcNames.Add(lcBrand);
            }
            return lcNames;
        }

        public List<clsOrder> GetOrders()
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM orders", null);
            List<clsOrder> lcNames = new List<clsOrder>();
            clsOrder lcOrder;
            foreach (DataRow dr in lcResult.Rows)
            {
                lcOrder = new clsOrder();
                lcOrder.order_num = (int)dr["order_num"];
                lcOrder.model_id = (int)dr["model_id"];
                lcOrder.customer_name = dr["customer_name"].ToString();
                lcOrder.customer_address = dr["customer_address"].ToString();
                lcOrder.customer_phone = (int)dr["customer_phone"];
                lcOrder.order_date = (DateTime)dr["order_date"];
                lcNames.Add(lcOrder);
            }
            return lcNames;
        }

        public List<clsShoe> GetBrandShoes(string prBrand)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(1);
            par.Add("prBrand", prBrand);
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM shoes WHERE brand_name = @prBrand", par);
            List<clsShoe> lcNames = new List<clsShoe>();
            clsShoe lcShoe;
            foreach (DataRow dr in lcResult.Rows)
            {
                lcShoe = new clsShoe();
                lcShoe.model_id = dr["model_id"].ToString();
                lcShoe.brand_name = dr["brand_name"].ToString();
                lcShoe.catergory = Convert.ToChar(dr["catergory"]);
                lcShoe.size= (int)dr["size"];
                lcShoe.colour = dr["colour"].ToString();
                lcShoe.price = Convert.ToDecimal(dr["price"]);
                if (!string.IsNullOrEmpty(dr["used_condition"].ToString()))
                    lcShoe.used_condition = dr["used_condition"].ToString();
                try
                {
                    lcShoe.quantity = Convert.ToInt16(dr["quantity"]);
                } catch (Exception ex)
                {
                    // just incase of eror hapenoing here
                }
                lcNames.Add(lcShoe);
            }
            return lcNames;
        }

        public string PutBrand(clsBrand prBrand)
        {   // update
            try
            {
                int lcRecCount = clsDbConnection.Execute(
                    "UPDATE brand SET brand_descrip = @brand_descrip WHERE brand_name = @brand_name",
                    prepareBrandParameters(prBrand));
                if (lcRecCount == 1)
                    return "One brand updated";
                else
                    return "Unexpected brand update count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string DeleteShoe(string Model)
        {   // delete
            try
            {
                int lcRecCount = clsDbConnection.Execute(
                    "DELETE FROM shoes WHERE model_id=" + Model, null);
                if (lcRecCount == 1)
                    return "One shoe pair deleted";
                else
                    return "Unexpected shoe delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string DeleteBrand(string Name)
        {   // delete
            try
            {
                int lcRecCount = clsDbConnection.Execute(
                    "DELETE FROM brand WHERE brand_name='" + Name + "'", null);
                if (lcRecCount == 1)
                    return "One brand deleted";
                else
                    return "Unexpected brand delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string DeleteOrder(string Order)
        {   // delete
            try
            {
                int lcRecCount = clsDbConnection.Execute(
                    "DELETE FROM orders WHERE order_num=" + Order, null);
                if (lcRecCount == 1)
                    return "One order deleted";
                else
                    return "Unexpected order delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string PostBrand(clsBrand prBrand)
        {   // insert
            try
            {
                int lcRecCount = clsDbConnection.Execute(
                    "Insert Into brand Values(@brand_name, @brand_descrip)",
                       prepareBrandParameters(prBrand));
                if (lcRecCount == 1)
                    return "One brand inserted";
                else
                    return "Unexpected brand insert count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        private Dictionary<string, object> prepareBrandParameters(clsBrand prBrand)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(3);
            par.Add("brand_name", prBrand.brand_name);
            par.Add("brand_descrip", prBrand.brand_descrip);
            return par;
        }

        public string PutShoe(clsShoe prShoe)
        {   // update
            try
            {
                int lcRecCount = clsDbConnection.Execute("UPDATE shoes SET " +
                "price = @price, quantity = @quantity WHERE model_id=@model_id",
                prepareShoeParameters(prShoe));
                if (lcRecCount == 1)
                    return "One shoe updated";
                else
                    return "Unexpected shoe update count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string PostShoe(clsShoe prShoe)
        {   // insert
            try
            {
                int lcRecCount = clsDbConnection.Execute("INSERT INTO shoes " +
                "VALUES (@model_id, @brand_name, @size, @colour, @price, @used_condition, @quantity, @catergory)",
                prepareShoeParameters(prShoe));
                if (lcRecCount == 1)
                    return "One shoe inserted";
                else
                    return "Unexpected shoe insert count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        private Dictionary<string, object> prepareShoeParameters(clsShoe prShoe)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(10);
            par.Add("model_id", prShoe.model_id);
            par.Add("brand_name", prShoe.brand_name);
            par.Add("size", prShoe.size);
            par.Add("colour", prShoe.colour);
            par.Add("price", prShoe.price);
            par.Add("used_condition", prShoe.used_condition);
            par.Add("quantity", prShoe.quantity);
            par.Add("catergory", prShoe.catergory);
            return par;
        }

        public string PostOrder(clsOrder prOrder)
        {   // insert
            try
            {
                int lcRecCount = clsDbConnection.Execute("INSERT INTO order " +
                    "(model_id,customer_name,customer_address,customer_phone,order_date) " + 
                    "VALUES (@model_id, @customer_name, @customer_address, @customer_phone, @order_date)",
                prepareOrderParameters(prOrder));
                if (lcRecCount == 1)
                    return "One order inserted";
                else
                    return "Unexpected order insert count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        private Dictionary<string, object> prepareOrderParameters(clsOrder prOrder)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(10);
            par.Add("order_num", prOrder.order_num);
            par.Add("model_id", prOrder.model_id);
            par.Add("customer_name", prOrder.customer_name);
            par.Add("customer_address", prOrder.customer_address);
            par.Add("customer_phone", prOrder.customer_phone);
            par.Add("order_date", prOrder.order_date);
            return par;
        }
    }
}
