using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace ShoeShopApp
{
    public partial class frmBrand : Form
    {
        private clsBrand _Brand;

        private static Dictionary<string, frmBrand> _BrandFormList =
            new Dictionary<string, frmBrand>();

        private frmBrand()
        {
            InitializeComponent();
        }

        public static void Run(string prName, clsBrand prBrand)
        {
            frmBrand lcBrandForm;
            if (string.IsNullOrEmpty(prName) ||
            !_BrandFormList.TryGetValue(prName, out lcBrandForm))
            {
                lcBrandForm = new frmBrand();
                if (string.IsNullOrEmpty(prName))
                    lcBrandForm.SetDetails(new clsBrand());
                else
                {
                    _BrandFormList.Add(prName, lcBrandForm);
                    lcBrandForm.SetDetails(prBrand);
                }
            }
            else
            {
                lcBrandForm.Show();
                lcBrandForm.Activate();
            }
        }

        private async void refreshFormFromDB(string prBrandName)
        {
            lstShoes.DataSource = null;
            lstShoes.DataSource = await ServiceClient.GetBrandShoesAsync(prBrandName);
        }

        private void updateTitle(string prGalleryName)
        {
            if (!string.IsNullOrEmpty(prGalleryName))
                Text = "Brand Shoes - " + prGalleryName;
        }

        public void UpdateForm()
        {
            txtName.Text = _Brand.brand_name;
            txtDescription.Text = _Brand.brand_descrip;
            frmMain.Instance.ShopNameChanged += new frmMain.Notify(updateTitle);
            updateTitle(_Brand.brand_name);
        }

        public void SetDetails(clsBrand prBrand)
        {
            _Brand = prBrand;
            txtName.Enabled = string.IsNullOrEmpty(_Brand.brand_name);
            UpdateForm();
            if (!string.IsNullOrEmpty(_Brand.brand_name))
                refreshFormFromDB(_Brand.brand_name);
            frmMain.Instance.ShopNameChanged += new frmMain.Notify(updateTitle);
            updateTitle(_Brand.brand_name);
            Show();
        }

        private void pushData()
        {
            _Brand.brand_name = txtName.Text;
            _Brand.brand_descrip= txtDescription.Text;
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string lcReply = new InputBox(clsShoe.FACTORY_PROMPT).Answer;
                if (!string.IsNullOrEmpty(lcReply)) // not cancelled?
                {
                    clsShoe lcShoe = clsShoe.NewWork(Convert.ToChar(lcReply));
                    if (lcShoe != null) // valid shoe created?
                    {
                        if (txtName.Enabled && txtName.Text != "")       // new shoe not saved?
                        {
                            pushData();
                            await ServiceClient.InsertBrandAsync(_Brand);
                            txtName.Enabled = false;
                        }
                        lcShoe.brand_name = _Brand.brand_name;
                        frmShoe.DispatchShoeForm(lcShoe);
                        if (!string.IsNullOrEmpty(lcShoe.model_id)) // not cancelled?
                        {
                            refreshFormFromDB(_Brand.brand_name);
                            frmMain.Instance.UpdateDisplay();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }

        }

        private void lstShoes_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                frmShoe.DispatchShoeForm(lstShoes.SelectedItem as clsShoe);
                if (!string.IsNullOrEmpty(_Brand.brand_name))
                    refreshFormFromDB(_Brand.brand_name);
                frmMain.Instance.UpdateDisplay();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            int lcIndex = lstShoes.SelectedIndex;

            if (lcIndex >= 0 && MessageBox.Show("Are you sure?", "Deleting shoe", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show(await ServiceClient.DeleteShoeAsync(lstShoes.SelectedItem as clsShoe));
                refreshFormFromDB(_Brand.brand_name);
                frmMain.Instance.UpdateDisplay();

            }
        }

        private async void btnClose_Click(object sender, EventArgs e)
        {
            if (isValid() == true)
                try
                {
                    pushData();
                    if (txtName.Enabled && txtName.Text != "")
                    {
                        MessageBox.Show(await ServiceClient.InsertBrandAsync(_Brand));
                        frmMain.Instance.UpdateDisplay();
                        txtName.Enabled = false;
                    }
                    else if (txtName.Text != "")
                        MessageBox.Show(await ServiceClient.UpdateBrandAsync(_Brand));
                    Hide();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
        }

        private Boolean isValid()
        {
                return true;
        }

    }
}