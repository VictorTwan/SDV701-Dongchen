using System;
using System.Windows.Forms;

namespace ShoeShopApp

{
    public sealed partial class frmMain : Form
    {   //Singleton
        private static readonly frmMain _Instance = new frmMain();

        public delegate void Notify(string prShopName);

        public event Notify ShopNameChanged;

        private frmMain()
        {
            InitializeComponent();
        }

        public static frmMain Instance
        {
            get { return frmMain._Instance; }
        }

        private void updateTitle(string prShopName)
        {
            if (!string.IsNullOrEmpty(prShopName))
                Text = "Brands & Orders - " + prShopName;
        }

        public async void UpdateDisplay()
        {
            lstBrands.DataSource = null;
            lstBrands.DataSource = await ServiceClient.GetBrandsAsync();
            lstOrders.DataSource = null;
            lstOrders.DataSource = await ServiceClient.GetOrdersAsync();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                frmBrand.Run("",null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error adding new brand");
            }
        }

        private void lstBrands_DoubleClick(object sender, EventArgs e)
        {
            clsBrand lcKey;

            lcKey = (clsBrand)lstBrands.SelectedItem;
            if (lcKey != null)
                try
                {
                    frmBrand.Run(lcKey.brand_name,lcKey);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "This should never occur");
                }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            
            Close();
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            clsBrand lcKey;

            lcKey = (clsBrand)lstBrands.SelectedItem;
            if (lcKey != null && MessageBox.Show("Are you sure?", "Deleting brand", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                try
                {
                    MessageBox.Show(await ServiceClient.DeleteBrandAsync(lcKey.brand_name));
                    lstBrands.ClearSelected();
                    UpdateDisplay();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error deleting brand");
                }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            UpdateDisplay();
            ShopNameChanged += new Notify(updateTitle);
            ShopNameChanged(clsBrand.storename);
            updateTitle(clsBrand.storename);
        }

        private void btnGalName_Click(object sender, EventArgs e)
        {
            clsBrand.storename = new InputBox("Enter New Shop Name:").Answer;
            ShopNameChanged(clsBrand.storename);
        }

        private async void btnDltOrder_Click(object sender, EventArgs e)
        {
            clsOrder lcKey;

            lcKey = (clsOrder)lstOrders.SelectedItem;
            if (lcKey != null && MessageBox.Show("Are you sure?", "Deleting order", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                try
                {
                    MessageBox.Show(await ServiceClient.DeleteOrderAsync(lcKey.order_num.ToString()));
                    lstOrders.ClearSelected();
                    UpdateDisplay();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error deleting order");
                }
        }

        private void lstOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (lstOrders.Items.Count > 0)
                {
                    clsOrder lcOrder = (clsOrder)lstOrders.SelectedItem;
                    label2.Text = lcOrder.QuickView();
                }
            }
            catch (Exception ex)
            {
                //do nothing
            }
        }
    }
}