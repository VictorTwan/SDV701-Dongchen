namespace ShoeShopApp
{
    partial class frmShoe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.txtColour = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(97, 105);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(96, 21);
            this.txtPrice.TabIndex = 3;
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(9, 108);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(80, 15);
            this.Label2.TabIndex = 46;
            this.Label2.Text = "Price $";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(97, 45);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(96, 21);
            this.txtSize.TabIndex = 2;
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(9, 48);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(80, 15);
            this.Label1.TabIndex = 44;
            this.Label1.Text = "Size";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(97, 16);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(96, 21);
            this.txtName.TabIndex = 1;
            // 
            // Label3
            // 
            this.Label3.Location = new System.Drawing.Point(9, 18);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(80, 15);
            this.Label3.TabIndex = 40;
            this.Label3.Text = "Model ID";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(225, 41);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(104, 21);
            this.btnCancel.TabIndex = 21;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(225, 11);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(104, 21);
            this.btnOK.TabIndex = 20;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // txtColour
            // 
            this.txtColour.Location = new System.Drawing.Point(97, 75);
            this.txtColour.Name = "txtColour";
            this.txtColour.Size = new System.Drawing.Size(96, 21);
            this.txtColour.TabIndex = 47;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(9, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 15);
            this.label4.TabIndex = 48;
            this.label4.Text = "Colour";
            // 
            // frmShoe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 226);
            this.Controls.Add(this.txtColour);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.txtSize);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Name = "frmShoe";
            this.Text = "Shoe Details";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox txtPrice;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtSize;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtName;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Button btnCancel;
        internal System.Windows.Forms.Button btnOK;
        internal System.Windows.Forms.TextBox txtColour;
        internal System.Windows.Forms.Label label4;
    }
}