namespace ShoeShopApp
{
    public sealed partial class frmShoeNew : ShoeShopApp.frmShoe
    {   //Singleton
        private static readonly frmShoeNew Instance = new frmShoeNew();

        private frmShoeNew()
        {
            InitializeComponent();
        }

        public static void Run(clsShoe prShoe)
        {
            Instance.SetDetails(prShoe);
        }

        protected override void updateForm()
        {
            base.updateForm();
            txtQuantity.Text = _Shoe.quantity.ToString();
        }

        protected override void pushData()
        {
            base.pushData();
            _Shoe.quantity = int.Parse(txtQuantity.Text);
            _Shoe.used_condition = "";
        }

    }
}

