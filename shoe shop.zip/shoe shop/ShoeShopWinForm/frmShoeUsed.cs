namespace ShoeShopApp
{
    public sealed partial class frmShoeUsed : ShoeShopApp.frmShoe
    {   //Singleton
        public static readonly frmShoeUsed Instance = new frmShoeUsed();

        private frmShoeUsed()
        {
            InitializeComponent();
        }

        public static void Run(clsShoe prShoe)
        {
            Instance.SetDetails(prShoe);
        }

        protected override void updateForm()
        {
            base.updateForm();
            txtCondition.Text = _Shoe.used_condition;
            txtCondition.Enabled = string.IsNullOrEmpty(_Shoe.used_condition);
        }

        protected override void pushData()
        {
            base.pushData();  
            _Shoe.used_condition = txtCondition.Text;
            _Shoe.quantity = 1;
        }
    }
}

