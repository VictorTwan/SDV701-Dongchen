using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ShoeShopApp
{
    public partial class frmShoe : Form
    {
        protected clsShoe _Shoe;

        public delegate void LoadShoeFormDelegate(clsShoe prWork);

        public static Dictionary<char, Delegate> _ShoeForm = new Dictionary<char, Delegate>
        {
            {'N', new LoadShoeFormDelegate(frmShoeNew.Run)},
            {'U', new LoadShoeFormDelegate(frmShoeUsed.Run)},
        };

        public static void DispatchShoeForm(clsShoe prShoe)
        {
            _ShoeForm[prShoe.catergory].DynamicInvoke(prShoe);
        }

        public frmShoe()
        {
            InitializeComponent();
        }

        public void SetDetails(clsShoe prShoe)
        {
            _Shoe = prShoe;
            updateForm();
            ShowDialog();
        }

        private async void btnOK_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                pushData();
                if (txtName.Enabled)
                    MessageBox.Show(await ServiceClient.InsertShoeAsync(_Shoe));
                else
                    MessageBox.Show(await ServiceClient.UpdateShoeAsync(_Shoe));
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        protected virtual bool isValid()
        {
            return true;
        }

        protected virtual void updateForm()
        {
            txtName.Text = _Shoe.model_id;
            txtName.Enabled = string.IsNullOrEmpty(_Shoe.model_id);
            txtSize.Text = _Shoe.size.ToString();
            txtSize.Enabled = _Shoe.size == 0;
            txtColour.Text = _Shoe.colour;
            txtColour.Enabled = string.IsNullOrEmpty(_Shoe.colour);
            txtPrice.Text = _Shoe.price.ToString();
        }

        protected virtual void pushData()
        {
            _Shoe.model_id = txtName.Text;
            _Shoe.size = Convert.ToInt16(txtSize.Text);
            _Shoe.colour = txtColour.Text;
            _Shoe.price = Convert.ToDecimal(txtPrice.Text);
        }

    }
}