namespace ShoeShopApp
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValue = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.lstBrands = new System.Windows.Forms.ListBox();
            this.btnGalName = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lstOrders = new System.Windows.Forms.ListBox();
            this.btnDltOrder = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblValue
            // 
            this.lblValue.Location = new System.Drawing.Point(87, 387);
            this.lblValue.Name = "lblValue";
            this.lblValue.Size = new System.Drawing.Size(68, 15);
            this.lblValue.TabIndex = 13;
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(423, 205);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(182, 30);
            this.btnQuit.TabIndex = 11;
            this.btnQuit.Text = "Quit";
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(19, 205);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(134, 30);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(19, 169);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(134, 30);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(17, 12);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(136, 15);
            this.Label1.TabIndex = 8;
            this.Label1.Text = "Brands";
            // 
            // lstBrands
            // 
            this.lstBrands.ItemHeight = 12;
            this.lstBrands.Location = new System.Drawing.Point(17, 27);
            this.lstBrands.Name = "lstBrands";
            this.lstBrands.Size = new System.Drawing.Size(136, 136);
            this.lstBrands.TabIndex = 7;
            this.lstBrands.DoubleClick += new System.EventHandler(this.lstBrands_DoubleClick);
            // 
            // btnGalName
            // 
            this.btnGalName.Location = new System.Drawing.Point(423, 169);
            this.btnGalName.Name = "btnGalName";
            this.btnGalName.Size = new System.Drawing.Size(182, 30);
            this.btnGalName.TabIndex = 14;
            this.btnGalName.Text = "Store Name";
            this.btnGalName.Click += new System.EventHandler(this.btnGalName_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(173, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 15);
            this.label3.TabIndex = 16;
            this.label3.Text = "Orders";
            // 
            // lstOrders
            // 
            this.lstOrders.ItemHeight = 12;
            this.lstOrders.Location = new System.Drawing.Point(173, 27);
            this.lstOrders.Name = "lstOrders";
            this.lstOrders.Size = new System.Drawing.Size(226, 136);
            this.lstOrders.TabIndex = 15;
            this.lstOrders.SelectedIndexChanged += new System.EventHandler(this.lstOrders_SelectedIndexChanged);
            // 
            // btnDltOrder
            // 
            this.btnDltOrder.Location = new System.Drawing.Point(175, 169);
            this.btnDltOrder.Name = "btnDltOrder";
            this.btnDltOrder.Size = new System.Drawing.Size(224, 30);
            this.btnDltOrder.TabIndex = 17;
            this.btnDltOrder.Text = "Delete";
            this.btnDltOrder.Click += new System.EventHandler(this.btnDltOrder_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(423, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 136);
            this.label2.TabIndex = 18;
            this.label2.Text = "Order Details: ";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 248);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnDltOrder);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lstOrders);
            this.Controls.Add(this.btnGalName);
            this.Controls.Add(this.lblValue);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.lstBrands);
            this.Name = "frmMain";
            this.Text = "Shoe Shop";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label lblValue;
        internal System.Windows.Forms.Button btnQuit;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnAdd;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ListBox lstBrands;
        internal System.Windows.Forms.Button btnGalName;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.ListBox lstOrders;
        internal System.Windows.Forms.Button btnDltOrder;
        private System.Windows.Forms.Label label2;
    }
}

