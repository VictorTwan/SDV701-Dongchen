﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

namespace ShoeShopApp
{
    public static class ServiceClient
    { //make call to service and return message or datas
        internal async static Task<List<clsBrand>> GetBrandsAsync()
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsBrand>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/shoe/GetBrands/"));
        }

        internal async static Task<List<clsOrder>> GetOrdersAsync()
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsOrder>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/shoe/GetOrders/"));
        }

        internal async static Task<List<clsShoe>> GetBrandShoesAsync(string prBrand)
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsShoe>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/shoe/GetBrandShoes?prBrand=" + prBrand));
        }
    
        private async static Task<string> InsertOrUpdateAsync<TItem>(TItem prItem, string prUrl, string prRequest)
        {
            using (HttpRequestMessage lcReqMessage = new HttpRequestMessage(new HttpMethod(prRequest), prUrl))
            using (lcReqMessage.Content =
        new StringContent(JsonConvert.SerializeObject(prItem), Encoding.Default, "application/json"))
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.SendAsync(lcReqMessage);
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
        }

        internal async static Task<string> UpdateShoeAsync(clsShoe _Shoe)
        {
            return await InsertOrUpdateAsync(_Shoe, "http://localhost:60064/api/shoe/PutShoe", "PUT");
        }

        internal async static Task<string> InsertShoeAsync(clsShoe _Shoe)
        {
            return await InsertOrUpdateAsync(_Shoe, "http://localhost:60064/api/shoe/PostShoe", "POST");
        }

        internal async static Task<string> InsertBrandAsync(clsBrand prBrand)
        {
            return await InsertOrUpdateAsync(prBrand, "http://localhost:60064/api/shoe/PostBrand", "POST");
        }

        internal async static Task<string> UpdateBrandAsync(clsBrand prBrand)
        {
            return await InsertOrUpdateAsync(prBrand, "http://localhost:60064/api/shoe/PutBrand", "PUT");
        }

        internal async static Task<string> DeleteShoeAsync(clsShoe prShoe)
        {
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.DeleteAsync
                ($"http://localhost:60064/api/shoe/DeleteShoe?Model={prShoe.model_id.ToString()}");
                return await lcRespMessage.Content.ReadAsStringAsync();

            }

        }

        internal async static Task<string> DeleteBrandAsync(string prName)
        {
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.DeleteAsync
            ($"http://localhost:60064/api/shoe/DeleteBrand?Name={prName}");
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
            throw new NotImplementedException();
        }

        internal async static Task<string> DeleteOrderAsync(string prOrderNum)
        {
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.DeleteAsync
            ($"http://localhost:60064/api/shoe/DeleteOrder?Order={prOrderNum.ToString()}");
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
            throw new NotImplementedException();
        }
    }
}
